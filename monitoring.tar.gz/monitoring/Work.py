#! usr/bin/python
# -*- coding: utf-8 -*-

from PropertiesUtil import *
import subprocess
import socket
import time

class Work(object):
    def __init__(self):
        pass
    def doWork(self):
        #打开websocket通道
        #sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        #sock.connect((properties['host'], properties['port']))
        while True:
            fileName = 'conf.properties'
            #读取配置文件
            p=Properties(fileName)
            properties = p.getProperties()
            print properties['file']
            files = properties['file'].split('|')
            strout = []
            errout = []
            for k in files:
                #shell 后台执行命令
                p = subprocess.Popen('nohup python %s'%(k) ,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
                #获得shell的输出值,和error信息
                stdout,stderr = p.communicate()
                strout.append(stdout)
                errout.append(stderr)
                #print 'stdout : ',stdout
                #print 'stderr : ',stderr
            #发送websocket数据
            #sock.send(strout)
            print 'strout----',strout
            print 'errout----',errout
            #休眠5秒
            time.sleep(3)
        #关闭连接
        sock.close()
        print '执行结束'
if __name__=='__main__':
    Work().doWork()
