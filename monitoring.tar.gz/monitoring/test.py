def test():
    print 'Hello python'
    #raise ValueError, 'my raise'

if __name__=='__main__':
    test()
